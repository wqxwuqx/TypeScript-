function add(x: number, y: number) : number {
    return x + y 
}

console.log(add(1,2))