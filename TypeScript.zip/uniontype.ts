function disp(number : string | string[]) {
    if (typeof number == "string") {
        console.log(number)
    } else {
        let i
        for(i = 0; i <= number.length; i++) {
            console.log(number[i])
        }
    }
}

disp("Runoob") 
console.log("输出数组....") 
disp(["Runoob","Google","Taobao","Facebook"])
