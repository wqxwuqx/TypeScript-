var num : number = 5
var i : number
var foctorial = 1

for (i = num; i >= 1; i--) {
    foctorial *= i
}
console.log(foctorial)