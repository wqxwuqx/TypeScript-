const message : string = "hello world!"
console.log(message)