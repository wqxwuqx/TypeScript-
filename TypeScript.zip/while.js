var num1 = 5;
var foctorial1 = 1;
while (num1 >= 1) {
    foctorial1 = foctorial1 * num1;
    num1--;
}
console.log("5的阶乘是" + foctorial1);
