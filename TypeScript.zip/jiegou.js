var tuple = [10, "Runoob", "Taobao", "Google"];
var a = tuple[0], b = tuple[1], c = tuple.slice(2);
console.log(a);
console.log(b);
console.log(c);
