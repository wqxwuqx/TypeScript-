var j;
var n = "a b c d";
for (j in n) {
    console.log(n[j]);
}
