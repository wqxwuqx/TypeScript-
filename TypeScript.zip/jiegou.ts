let tuple = [10, "Runoob", "Taobao", "Google"]

let [a, b, ...c] = tuple

console.log(a);
console.log(b);
console.log(c);