let num1 : number = 5
let foctorial1 : number = 1

while (num1 >= 1) {
    foctorial1 = foctorial1 * num1
    num1--
}
console.log("5的阶乘是" + foctorial1)