var str = '1';
var str2 = str;
console.log(str2);
console.log(typeof str2);
