var shengming;
console.log(shengming);
