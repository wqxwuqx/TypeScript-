var j : any
var n : any = "a b c d"

for (j in n) {
    console.log(n[j])
}