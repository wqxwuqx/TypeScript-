var global_num = 12
class Numbers {
    num_val = 13
    static sval = 10

    storeNum():void{
       var local_num = 14
    }
}
console.log("全局变量为: "+global_num)  
console.log(Numbers.sval)
var oop = new Numbers()
console.log("实例变量: "+oop.num_val)