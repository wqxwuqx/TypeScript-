function add(x, y) {
    return x + y;
}
console.log(add(1, 2));
