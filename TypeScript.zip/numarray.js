var num = [2, 4, 6, 8];
console.log(num);
