let n : number = 10

do {
    console.log(n)
    n--
}while(n >= 0)