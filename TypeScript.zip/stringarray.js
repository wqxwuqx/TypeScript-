var sites;
sites = ["Google", "Runoob", "taobao"];
console.log(sites);
