let someArray = [1, "string", false]

for (let entry of someArray) {
    console.log(entry)
}