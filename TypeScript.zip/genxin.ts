let mytuple1 = [10, "Runoob", "taobao", "typeScript"]

console.log("元组的第一个元素为：" + mytuple1[0]) 

mytuple1[0] = 121
console.log("元组的第一个元素为：" + mytuple1[0]) 