let sites : string[];
sites = ["Google", "Runoob", "taobao"]

console.log(sites)