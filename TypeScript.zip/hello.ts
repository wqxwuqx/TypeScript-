var hello : string = "hello wqx22"
console.log(hello)