class Site {
    name():void{
        console.log("Runoob")
    }
}
var obj = new Site()
obj.name()