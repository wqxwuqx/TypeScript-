var hello = "hello wqx22";
console.log(hello);
