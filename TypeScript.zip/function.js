function greet() {
    return "hello world!";
}
function caller() {
    var msg = greet();
    console.log(msg);
}
caller();
