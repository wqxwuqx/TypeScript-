var shengming : number
console.log(shengming)