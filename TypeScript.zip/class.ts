class person {
    
}