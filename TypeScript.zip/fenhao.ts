console.log("Runoob");
console.log("Google");
// TypeScript 分号是可选的

/* 
多行注释
这是一个多行注释
这是一个多行注释
这是一个多行注释
*/
