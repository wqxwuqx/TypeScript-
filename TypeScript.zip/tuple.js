var mytuple = [10, "Runoob"];
console.log(mytuple[0]);
console.log(mytuple[1]);
