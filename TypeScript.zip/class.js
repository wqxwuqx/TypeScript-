var person = /** @class */ (function () {
    function person() {
    }
    return person;
}());
