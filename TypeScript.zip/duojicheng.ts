class Root {
    str: string
}

class child extends Root {}

class leaf extends child {}

let obj1 = new leaf()

obj1.str = "hello"

console.log(obj1.str)