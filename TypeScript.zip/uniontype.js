function disp(number) {
    if (typeof number == "string") {
        console.log(number);
    }
    else {
        var i = void 0;
        for (i = 0; i <= number.length; i++) {
            console.log(number[i]);
        }
    }
}
disp("Runoob");
console.log("输出数组....");
disp(["Runoob", "Google", "Taobao", "Facebook"]);
