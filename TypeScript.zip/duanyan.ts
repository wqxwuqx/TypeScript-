var str = '1'
var str2 : number = <number> <any> str
console.log(str2) 
console.log(typeof str2) 