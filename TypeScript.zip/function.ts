function greet() : string {
    return "hello world!"
}

function caller() {
    let msg = greet()
    console.log(msg)
}

caller()